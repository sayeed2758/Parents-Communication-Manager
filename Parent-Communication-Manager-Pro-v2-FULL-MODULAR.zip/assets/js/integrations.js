export const integrationKeys={students:["ezee_students"],attendance:["ezee_attendance","attendance_records"],results:["ezee_results","result_records"],fees:["ezee_fees","fee_records"]};
function readJSON(key){try{const raw=localStorage.getItem(key);return raw?JSON.parse(raw):null}catch{return null}}
export function detectIntegrations(){const out={};for(const [name,keys] of Object.entries(integrationKeys)){const found=keys.find(k=>localStorage.getItem(k)!==null);out[name]={detected:Boolean(found),key:found||"",value:found?readJSON(found):null}}return out}
export function importExternalStudents(){const x=detectIntegrations().students;return x.detected&&Array.isArray(x.value)?x.value:[]}
export function importExternalMetrics(){const d=detectIntegrations();return {attendance:d.attendance.value,results:d.results.value,fees:d.fees.value}}
export function integrationManifest(){return Object.fromEntries(Object.entries(integrationKeys).map(([k,v])=>[k,[...v]]))}
